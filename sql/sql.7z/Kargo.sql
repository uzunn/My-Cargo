/*
 Navicat Premium Data Transfer

 Source Server         : tt
 Source Server Type    : SQL Server
 Source Server Version : 12002000
 Source Host           : Kargo-KTU.mssql.somee.com:1433
 Source Catalog        : Kargo-KTU
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 12002000
 File Encoding         : 65001

 Date: 09/11/2022 20:45:23
*/


-- ----------------------------
-- Table structure for Kargo
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[Kargo]') AND type IN ('U'))
	DROP TABLE [dbo].[Kargo]
GO

CREATE TABLE [dbo].[Kargo] (
  [kargo_no] int  IDENTITY(1,1) NOT NULL,
  [sube_no] int  NOT NULL,
  [personel_no] int NOT NULL,
  [tur] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [agirlik] int NOT NULL,
  [gonderici_isim] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [gonderici_soyisim] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [gonderici_kimlikno] bigint NOT NULL,
  [gonderici_telefon] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [gonderici_eposta] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [alici_isim] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [alici_soyisim] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [alici_kimlikno] bigint NOT NULL,
  [alici_telefon] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [alici_eposta] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [alici_adres] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [dbo].[Kargo] SET (LOCK_ESCALATION = TABLE)
GO

-- ----------------------------
-- Primary Key structure for table Kargo
-- ----------------------------
ALTER TABLE [dbo].[Kargo] ADD CONSTRAINT [PK__Kargo__8580B1458043D126] PRIMARY KEY CLUSTERED ([kargo_no])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

