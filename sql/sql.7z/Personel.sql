/*
 Navicat Premium Data Transfer

 Source Server         : tt
 Source Server Type    : SQL Server
 Source Server Version : 12002000
 Source Host           : Kargo-KTU.mssql.somee.com:1433
 Source Catalog        : Kargo-KTU
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 12002000
 File Encoding         : 65001

 Date: 09/11/2022 20:36:08
*/


-- ----------------------------
-- Table structure for Personel
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[Personel]') AND type IN ('U'))
	DROP TABLE [dbo].[Personel]
GO

CREATE TABLE [dbo].[Personel] (
  [sicil_no] int  NOT NULL,
  [sube_no] int  NOT NULL,
  [ad] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [soyad] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [sifre] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [yetki] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [kimlik_no] bigint  NOT NULL,
  [adres] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [telefon] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [mail] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [dbo].[Personel] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Primary Key structure for table Personel
-- ----------------------------
ALTER TABLE [dbo].[Personel] ADD CONSTRAINT [PK__personel__3213E83F41FD3058] PRIMARY KEY CLUSTERED ([sicil_no])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

