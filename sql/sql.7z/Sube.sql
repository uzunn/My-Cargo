/*
 Navicat Premium Data Transfer

 Source Server         : tt
 Source Server Type    : SQL Server
 Source Server Version : 12002000
 Source Host           : Kargo-KTU.mssql.somee.com:1433
 Source Catalog        : Kargo-KTU
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 12002000
 File Encoding         : 65001

 Date: 09/11/2022 20:36:22
*/


-- ----------------------------
-- Table structure for Sube
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[Sube]') AND type IN ('U'))
	DROP TABLE [dbo].[Sube]
GO

CREATE TABLE [dbo].[Sube] (
  [sube_no] int  NOT NULL,
  [ad] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [adres] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [dbo].[Sube] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Primary Key structure for table Sube
-- ----------------------------
ALTER TABLE [dbo].[Sube] ADD CONSTRAINT [PK__Sube__6467B2105B1FC212] PRIMARY KEY CLUSTERED ([sube_no])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

